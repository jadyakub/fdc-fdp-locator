# FDC & FDP GeoLocator

Netlify-ready static web app.

Files:
- index.html
- RNU_FDC_FDP_Masterlist.csv

Deploy:
1. Upload this folder or ZIP to Netlify.
2. Make sure `index.html` and `RNU_FDC_FDP_Masterlist.csv` stay in the same root folder.
3. Search FDC/FDP/DP/FTB and click Navigate to open Google Maps.
